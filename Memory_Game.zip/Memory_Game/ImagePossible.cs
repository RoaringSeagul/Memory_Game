﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Memory_Game
{
    class ImagePossible
    {
        public string imageName { get; set; }
        public bool IsUsed { get; set; }
        public bool IsRemoved { get; set; }
    }
}
