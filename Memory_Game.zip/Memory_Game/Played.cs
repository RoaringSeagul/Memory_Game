﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Memory_Game
{
    class Played
    {
        public int Id { get; set; }
        public string PlayedCoords { get; set; }
    }
}
