﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Memory_Game
{
    class GameInfo
    {
        public string Theme { get; set; }
        public string PlayerFirstName { get; set; }
        public string PlyerLastName { get; set; }
        public DateTime DateGameStart { get; set; }
    }
}
