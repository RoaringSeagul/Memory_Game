﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Memory_Game
{
    public class ImageCarte
    {
        public string imageName { get; set; }
    }
}
